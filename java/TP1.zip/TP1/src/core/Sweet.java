package core;

public class Sweet {
	public String name;
	public int xp;
	public boolean alreadyEaten=false;
	
	public Sweet(String name, int xp) {
		this.name = name;
		this.xp = xp;
	}

}
