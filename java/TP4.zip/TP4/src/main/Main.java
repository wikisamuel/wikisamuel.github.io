package main;

import java.util.HashMap;
import java.util.Map;

import core.GreatBall;
import core.Player;
import core.Pokeball;
import core.Pokemon;
import core.Specie;
import core.Sweet;
import specialpowers.Beautiful;
import specialpowers.BeautifulCleverCharmander;

public class Main {

	public static void main(String[] args) {
		System.out.println("hello world!");
		Pokemon myPokemon = new Pokemon("Bulbazaure 1", 12f, 1, Specie.BULBAZAURE);
		System.out.println(myPokemon.getSurname());
		System.out.println(myPokemon.getSpecie().getName());
		Pokemon myPokemon2 = new Pokemon("Bulbazaure 2", 12f, 58, Specie.BULBAZAURE);
		System.out.println(myPokemon.getLevel());
		System.out.println(myPokemon.getId());
		System.out.println(myPokemon2.getId());
		
		System.out.println(myPokemon);
		
		for(int i=0; i<100; i++){
			myPokemon.receiveXP(1);
			System.out.println(myPokemon);
		}
		
		Sweet s = new Sweet("malabar", 3,7);
		myPokemon.eatSweet(s);
		System.out.println(myPokemon);
		System.out.println(myPokemon2);
		myPokemon2.eatSweet(s);
		System.out.println(myPokemon2);
		
		/*
		 * Slide 6 : combat
		 */
		while(myPokemon.getHp()>0 && myPokemon2.getHp()>0) {
			myPokemon.attack(myPokemon2);
			if(myPokemon2.getHp()>0) {
				myPokemon2.attack(myPokemon);
			}
		}
		if(myPokemon.getHp()>0) {
			myPokemon.receiveXP(5);
		}else {
			myPokemon2.receiveXP(5);
		}
		System.out.println(myPokemon);
		System.out.println(myPokemon2);
		
		System.out.println(s);
		Pokeball myPokeball = new GreatBall("myGreatBall", 10, 5);
		System.out.println(myPokeball);
		System.out.println(myPokeball.realEfficiency()); //3*5 = 15
		
		Player p1 = Player.getInstance();
		Player p2 = Player.getInstance();
		
		System.out.println(p1);
		System.out.println(p2);
		
		p1.addToInventory(s);
		/*
		 * On peut ajouter � cette liste 
		 */
		
		System.out.println(myPokemon2.getLevel());
		System.out.println(p1.getTotalPriceOfInventory());
		System.out.println(p1);
		
		Sweet s2 = new Sweet("malabar", 3,7);
		Sweet s3 = new Sweet("malabar", 3,7);
		Sweet s4 = new Sweet("malabar", 3,7);
		Sweet s5 = new Sweet("malabar", 3,7);
		Sweet s6 = new Sweet("malabar", 3,7);
		Sweet s7 = new Sweet("malabar", 3,7);
		Sweet s8 = new Sweet("malabar", 3,7);
		Sweet s9 = new Sweet("malabar", 3,7);
		Sweet s10 = new Sweet("malabar", 3,7);
		Sweet s11 = new Sweet("malabar", 3,7);
		
		p1.addToInventory(s2);
		p1.addToInventory(s3);
		p1.addToInventory(s4);
		p1.addToInventory(s5);
		p1.addToInventory(s6);
		p1.addToInventory(s7);
		p1.addToInventory(s8);
		p1.addToInventory(s9);
		p1.addToInventory(s10);
		p1.addToInventory(s11);
		
		System.out.println(p1);
		
		Pokemon myPokemon3 = new Pokemon("Bulbazaure 3", 12f, 1, Specie.BULBAZAURE);
		Pokemon myPokemon4 = new Pokemon("Charmander 1", 12f, 1, Specie.CHARMANDER);
		
		myPokemon4.defend();
		myPokemon4.defend();
		myPokemon4.defend();
		
		System.out.println(myPokemon4.getHp());
		
		myPokemon3.attack(myPokemon4);
		/*
		 * les d�g�ts sont de strength*(1-target.defense*1.0/100)
		 * soit ici 10 * ( 1 - 0.3 ) = 7
		 * reste 3 HP � l'issue ! 
		 */
		
		System.out.println(myPokemon4.getHp());
		
		Beautiful myPokemon5 = new BeautifulCleverCharmander("Charmander 2", 12f, 1);
		myPokemon5.charm();
		
		Map<Integer, Integer> a = new HashMap<Integer,Integer>();
		a.put(1, 1);
		a.put(1, 2);
	}

}
