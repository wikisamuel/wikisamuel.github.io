package exceptions;

public class FullInventoryException extends Exception {

}
