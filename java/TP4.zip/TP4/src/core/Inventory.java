package core;

import java.util.HashSet;
import java.util.Set;

import exceptions.FullInventoryException;

public class Inventory {
	private Set<Item> myInventory = new HashSet<Item>();
	
	private static final int MAX_SIZE = 10;

	public void addItem(Item i) throws FullInventoryException {
		if(myInventory.size()<MAX_SIZE) {
			myInventory.add(i);
		}else {
			throw new FullInventoryException();
		}
	}
	
	public int totalPrice() {
		int res = 0;
		for(Item i : myInventory) {
			res += i.getPrice();
		}
		/*
		 * Pour aller plus loin (HORS PROGRAMME),
		 * on aurait pu faire :
		 * 
		 * return myInventory.stream().mapToInt(Item::getPrice).sum();
		 */
		return res;
	}

	@Override
	public String toString() {
		String res = "";
		for(Item i : myInventory) {
			res += i.toString()+" , ";
		}
		return res;
	}
	
	
}
