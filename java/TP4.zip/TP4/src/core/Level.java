package core;

public class Level {
	
	private static final int[] levels = {100, 30, 15, 5, 0};
	
	public static int getLevelFromXp(int xp) {
		int i = 0;
		
		while(xp<levels[i] && i<levels.length) {
			i++;
		}
		
		return levels.length-i;
	}
	
}
