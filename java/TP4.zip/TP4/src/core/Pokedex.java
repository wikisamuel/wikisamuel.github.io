package core;

import java.util.HashMap;
import java.util.Map;

public class Pokedex {
	private Map<Specie,Seen> pokedex;

	public Pokedex() {
		this.pokedex = new HashMap<Specie,Seen>();
		for(Specie specie : Specie.values()) {
			pokedex.put(specie, Seen.NEVER_ENCOUNTERED);
		}
	}
	
	public void setFought(Specie specie) {
		pokedex.put(specie, Seen.FOUGHT);
	}
	
	public boolean isFought(Specie specie) {
		return pokedex.get(specie).equals(Seen.FOUGHT);
	}
	
}
