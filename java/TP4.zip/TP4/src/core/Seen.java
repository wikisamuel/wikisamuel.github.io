package core;

public enum Seen {
	ENCOUNTERED, FOUGHT, NEVER_ENCOUNTERED;
}
