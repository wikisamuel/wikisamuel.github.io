package core;

import exceptions.FullInventoryException;

public class Player {
	//This is the SINGLETON pattern

	private Inventory inventory = new Inventory();
	
	private Pokedex pokedex = new Pokedex();
	
	private static Player onePlayer;
	
	private Player(){
		super();
	}
	
	public static Player getInstance(){
		if(onePlayer==null){
			onePlayer = new Player();
		}
		return onePlayer;
	}

	public void addToInventory(Item i) {
		try {
			getInstance().inventory.addItem(i);
		}
		catch(FullInventoryException e) {
			System.out.println("Fail ! The inventory is full !");
		}
	}
	
	public int getTotalPriceOfInventory() {
		return getInstance().inventory.totalPrice();
	}

	@Override
	public String toString() {
		return "Player [inventory=" + inventory + "]";
	}
	
	

}
