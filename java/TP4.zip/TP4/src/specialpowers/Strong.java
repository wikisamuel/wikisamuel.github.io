package specialpowers;

public interface Strong {
	void triggerAnEarthquake();
	
	/*
	 * Subtilit� HORS PROGRAMME :
	 * On pourrait aussi �crire une
	 * action par d�faut:
	 * 
	 * default void triggerAnEarthquake() {
	 * 	System.out.println("Brr");
	 * }
	 * 
	 * Pour ne pas avoir � impl�menter
	 * ce comportement dans les toutes les
	 * classes concr�tres qui impl�mentent
	 * cette interface.
	 */
}
