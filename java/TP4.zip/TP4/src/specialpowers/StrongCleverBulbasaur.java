package specialpowers;

import core.Pokemon;
import core.Specie;

public class StrongCleverBulbasaur extends Pokemon implements Strong, Clever {

	public StrongCleverBulbasaur(String surname, float size, int level) {
		super(surname, size, level, Specie.BULBAZAURE);
	}

	@Override
	public void solveAnEquation() {
		System.out.println("x+2=4");
	}

	@Override
	public void triggerAnEarthquake() {
		System.out.println("Brr");
	}

}
