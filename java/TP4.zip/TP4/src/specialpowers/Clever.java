package specialpowers;

public interface Clever {
	void solveAnEquation();
	
	/*
	 * Subtilit� HORS PROGRAMME :
	 * On pourrait aussi �crire une
	 * action par d�faut:
	 * 
	 * default void solveAnEquation() {
	 * 	System.out.println("x+2=4");
	 * }
	 * 
	 * Pour ne pas avoir � impl�menter
	 * ce comportement dans les toutes les
	 * classes concr�tres qui impl�mentent
	 * cette interface.
	 */
}
