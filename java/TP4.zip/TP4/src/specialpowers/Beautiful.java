package specialpowers;

public interface Beautiful {
	void charm();
	
	/*
	 * Subtilit� HORS PROGRAMME :
	 * On pourrait aussi �crire une
	 * action par d�faut:
	 * 
	 * default void charm() {
	 * 	System.out.println("Hey !");
	 * }
	 * 
	 * Pour ne pas avoir � impl�menter
	 * ce comportement dans les toutes les
	 * classes concr�tres qui impl�mentent
	 * cette interface.
	 */
}
