package core;

public class Inventory {

}
